"""Subway Surfers Clone - Main Entry Point"""
from game import Game


if __name__ == "__main__":
    game = Game()
    game.run()
