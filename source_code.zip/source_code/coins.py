"""Coins implementation"""
import pygame
from config import *
import random


class Coin(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.image = pygame.Surface((COIN_SIZE, COIN_SIZE))
        self.image.fill(YELLOW)
        pygame.draw.circle(self.image, YELLOW, (COIN_SIZE // 2, COIN_SIZE // 2), COIN_SIZE // 2)
        self.rect = self.image.get_rect(center=(x, y))
    
    def update(self, speed):
        self.rect.y += speed


class CoinManager:
    def __init__(self):
        self.coins = pygame.sprite.Group()
        self.spawn_rate = 120
        self.spawn_counter = 0
    
    def update(self, speed):
        self.coins.update(speed)
        
        # Remove off-screen coins
        for coin in self.coins:
            if coin.rect.y > SCREEN_HEIGHT:
                coin.kill()
        
        # Spawn new coins
        self.spawn_counter += 1
        if self.spawn_counter >= self.spawn_rate:
            self.spawn_counter = 0
            self.spawn_coin()
    
    def spawn_coin(self):
        """Spawn coin in random lane"""
        lane = random.randint(0, NUM_LANES - 1)
        x = lane * LANE_WIDTH + LANE_WIDTH // 2
        coin = Coin(x, -COIN_SIZE)
        self.coins.add(coin)
    
    def get_coins(self):
        return self.coins
