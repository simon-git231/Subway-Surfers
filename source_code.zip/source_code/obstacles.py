"""Obstacles implementation"""
import pygame
from config import *
import random


class Obstacle(pygame.sprite.Sprite):
    def __init__(self, x, y, lane):
        super().__init__()
        self.image = pygame.Surface((OBSTACLE_WIDTH, OBSTACLE_HEIGHT))
        self.image.fill(RED)
        self.rect = self.image.get_rect(topleft=(x, y))
        self.lane = lane
        self.speed = 0
    
    def update(self, speed):
        self.speed = speed
        self.rect.y += speed


class ObstacleManager:
    def __init__(self):
        self.obstacles = pygame.sprite.Group()
        self.spawn_rate = 80
        self.spawn_counter = 0
        self.last_lanes = []
    
    def update(self, speed):
        self.obstacles.update(speed)
        
        # Remove off-screen obstacles
        for obstacle in self.obstacles:
            if obstacle.rect.y > SCREEN_HEIGHT:
                obstacle.kill()
        
        # Spawn new obstacles
        self.spawn_counter += 1
        if self.spawn_counter >= self.spawn_rate:
            self.spawn_counter = 0
            self.spawn_obstacle()
    
    def spawn_obstacle(self):
        """Spawn obstacle(s) in random lane(s)"""
        # Pick 1-2 lanes randomly (avoid spawning in all 3 lanes at once)
        available_lanes = list(range(NUM_LANES))
        num_obstacles = random.randint(1, 2)
        
        for _ in range(num_obstacles):
            if available_lanes:
                lane = random.choice(available_lanes)
                available_lanes.remove(lane)
                x = lane * LANE_WIDTH + (LANE_WIDTH - OBSTACLE_WIDTH) // 2
                obstacle = Obstacle(x, -OBSTACLE_HEIGHT, lane)
                self.obstacles.add(obstacle)
    
    def get_obstacles(self):
        return self.obstacles
