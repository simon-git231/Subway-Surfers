"""Main game logic"""
import pygame
import sys
from config import *
from player import Player
from obstacles import ObstacleManager
from coins import CoinManager


class Game:
    def __init__(self):
        pygame.init()
        self.screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
        pygame.display.set_caption("Subway Surfers")
        self.clock = pygame.time.Clock()
        self.font = pygame.font.Font(None, 36)
        self.large_font = pygame.font.Font(None, 72)
        
        self.reset_game()
    
    def reset_game(self):
        """Reset game state"""
        self.player = Player(LANE_WIDTH + LANE_WIDTH // 2, SCREEN_HEIGHT - 80)
        self.obstacle_manager = ObstacleManager()
        self.coin_manager = CoinManager()
        
        self.game_speed = INITIAL_GAME_SPEED
        self.score = 0
        self.coins_collected = 0
        self.game_over = False
        self.game_over_time = 0
    
    def handle_input(self):
        """Handle player input"""
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return False
            
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_LEFT:
                    self.player.move_left()
                elif event.key == pygame.K_RIGHT:
                    self.player.move_right()
                elif event.key == pygame.K_UP or event.key == pygame.K_SPACE:
                    self.player.jump()
                elif event.key == pygame.K_DOWN:
                    self.player.roll()
                
                # Restart game on game over
                if self.game_over and event.key == pygame.K_SPACE:
                    self.reset_game()
                
                # Quit with ESC
                if event.key == pygame.K_ESCAPE:
                    return False
        
        return True
    
    def update(self):
        """Update game state"""
        if self.game_over:
            self.game_over_time += 1
            return
        
        # Increase game speed over time
        if self.game_speed < MAX_GAME_SPEED:
            self.game_speed += SPEED_INCREMENT
        
        # Update player and world
        self.player.update()
        self.obstacle_manager.update(self.game_speed)
        self.coin_manager.update(self.game_speed)
        
        # Award points
        self.score += BASE_POINTS
        
        # Check coin collection
        collected_coins = pygame.sprite.spritecollide(
            self.player, self.coin_manager.get_coins(), True
        )
        for coin in collected_coins:
            self.score += COIN_POINTS
            self.coins_collected += 1
        
        # Check collision with obstacles
        player_hit_rect = self.player.get_hit_rect()
        player_rect_sprite = pygame.sprite.Sprite()
        player_rect_sprite.rect = player_hit_rect
        
        collisions = pygame.sprite.spritecollide(
            player_rect_sprite, self.obstacle_manager.get_obstacles(), False
        )
        
        if collisions:
            self.game_over = True
            self.game_over_time = 0
    
    def draw(self):
        """Draw game state"""
        self.screen.fill(DARK_GRAY)
        
        # Draw lanes
        for i in range(1, NUM_LANES):
            pygame.draw.line(
                self.screen, GRAY,
                (i * LANE_WIDTH, 0),
                (i * LANE_WIDTH, SCREEN_HEIGHT),
                2
            )
        
        # Draw player
        self.screen.blit(self.player.image, self.player.rect)
        
        # Draw obstacles
        for obstacle in self.obstacle_manager.get_obstacles():
            self.screen.blit(obstacle.image, obstacle.rect)
        
        # Draw coins
        for coin in self.coin_manager.get_coins():
            self.screen.blit(coin.image, coin.rect)
        
        # Draw HUD
        score_text = self.font.render(f"Score: {self.score // 10}", True, WHITE)
        coins_text = self.font.render(f"Coins: {self.coins_collected}", True, YELLOW)
        speed_text = self.font.render(f"Speed: {self.game_speed:.1f}", True, WHITE)
        
        self.screen.blit(score_text, (10, 10))
        self.screen.blit(coins_text, (10, 50))
        self.screen.blit(speed_text, (10, 90))
        
        # Draw game over screen
        if self.game_over:
            overlay = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT))
            overlay.set_alpha(128)
            overlay.fill(BLACK)
            self.screen.blit(overlay, (0, 0))
            
            game_over_text = self.large_font.render("GAME OVER!", True, RED)
            score_text = self.font.render(f"Final Score: {self.score // 10}", True, WHITE)
            restart_text = self.font.render("Press SPACE to restart", True, WHITE)
            
            self.screen.blit(
                game_over_text,
                (SCREEN_WIDTH // 2 - game_over_text.get_width() // 2, 150)
            )
            self.screen.blit(
                score_text,
                (SCREEN_WIDTH // 2 - score_text.get_width() // 2, 250)
            )
            self.screen.blit(
                restart_text,
                (SCREEN_WIDTH // 2 - restart_text.get_width() // 2, 350)
            )
        
        pygame.display.flip()
    
    def run(self):
        """Main game loop"""
        running = True
        while running:
            running = self.handle_input()
            self.update()
            self.draw()
            self.clock.tick(FPS)
        
        pygame.quit()
        sys.exit()
