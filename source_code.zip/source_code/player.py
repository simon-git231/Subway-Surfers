"""Player character implementation"""
import pygame
from config import *


class Player(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.image = pygame.Surface((PLAYER_SIZE, PLAYER_SIZE))
        self.image.fill(BLUE)
        self.rect = self.image.get_rect(center=(x, y))
        
        self.lane = 1  # 0 = left, 1 = middle, 2 = right
        self.lane_x = [LANE_WIDTH // 2, LANE_WIDTH + LANE_WIDTH // 2, 2 * LANE_WIDTH + LANE_WIDTH // 2]
        self.rect.centerx = self.lane_x[self.lane]
        
        self.velocity_y = 0
        self.is_jumping = False
        self.is_rolling = False
        self.roll_duration = 0
        self.ground_level = y
        
    def move_left(self):
        if self.lane > 0:
            self.lane -= 1
            self.rect.centerx = self.lane_x[self.lane]
    
    def move_right(self):
        if self.lane < NUM_LANES - 1:
            self.lane += 1
            self.rect.centerx = self.lane_x[self.lane]
    
    def jump(self):
        if not self.is_jumping:
            self.is_jumping = True
            self.velocity_y = -PLAYER_JUMP_STRENGTH
    
    def roll(self):
        if not self.is_rolling and not self.is_jumping:
            self.is_rolling = True
            self.roll_duration = 30  # frames
    
    def update(self):
        # Apply gravity
        if self.is_jumping:
            self.velocity_y += GRAVITY
            self.rect.y += self.velocity_y
            
            # Check if landed
            if self.rect.y >= self.ground_level:
                self.rect.y = self.ground_level
                self.is_jumping = False
                self.velocity_y = 0
        
        # Handle rolling
        if self.is_rolling:
            self.roll_duration -= 1
            if self.roll_duration <= 0:
                self.is_rolling = False
                self.image = self.get_normal_image()
            else:
                self.image = self.get_roll_image()
    
    def get_normal_image(self):
        img = pygame.Surface((PLAYER_SIZE, PLAYER_SIZE))
        img.fill(BLUE)
        return img
    
    def get_roll_image(self):
        img = pygame.Surface((PLAYER_SIZE, PLAYER_SIZE // 2))
        img.fill(BLUE)
        padded_img = pygame.Surface((PLAYER_SIZE, PLAYER_SIZE))
        padded_img.fill(BLACK)
        padded_img.blit(img, (0, PLAYER_SIZE // 4))
        return padded_img
    
    def get_hit_rect(self):
        """Returns the actual collision rect considering rolling"""
        if self.is_rolling:
            return pygame.Rect(self.rect.x, self.rect.y + PLAYER_SIZE // 4, PLAYER_SIZE, PLAYER_SIZE // 2)
        return self.rect
